#include <iostream>
#include <string>
#include "windows.h"              //cabezeras
#include "ArbolOrnamental.h"

using namespace std;
ArbolOrnamental::ArbolOrnamental()
{
    //ctor                 //constructor
}

void ArbolOrnamental::msn() {                               //mensaje

   string o[20] = {"\t\t\t\t\t  A","r","b","o","l","e","s"," ","O","r","n","a","m","e","n","t","a","l","e","s\n\n"};
    for (int i=0;i<20;i++){
    cout<<o[i];
   }
}



ArbolOrnamental::~ArbolOrnamental()
{
    //dtor                                  //destructor
}
