#include <iostream>
#include <string>
#include "hoja.h"  //cabezeras
#include "Arbol.h"
#include"windows.h"
using namespace std;

Arbol::Arbol() //constructor de la clase
{

}


//////////////////////////////////////////
void Arbol::set_NComun(string val){
    NComun = val;                            //metodo set
}
string Arbol::get_NComun () {
    return NComun;                   //metodo get
}
//////////////////////////////////
void Arbol::set_Ncient(string val){  //metodo set
    Ncient = val;
}
string Arbol::get_Ncient() { //metodo get
    return Ncient;
}
////////////////////////////////////////
void Arbol::set_Familia(string val){  //metodo set
    Familia = val;
}
string Arbol::get_Familia(){ //metodo get
    return Familia;
}

/////////////////////////////////////////
void Arbol::msn(){ //mensaje

}
Arbol::~Arbol()
{                   //destructor de la case
    //dtor
}
