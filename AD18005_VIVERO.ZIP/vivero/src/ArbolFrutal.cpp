#include <iostream>
#include <string>
#include "windows.h"
#include"hoja.h"
#include"Arbol.h"          //cabezeras
#include "ArbolFrutal.h"

using namespace std;
ArbolFrutal::ArbolFrutal()
{                 //constructor de la clase
    //ctor
}
void Arbol();
void ArbolFrutal::msn(){
                                     //impresion de mensaje
   string o[20] = {"\t\t\t\t\t  A","r","b","o","l","e","s"," ","O","r","n","a","m","e","n","t","a","l","e","s\n\n"};
    for (int i=0;i<20;i++){
    cout<<o[i];
   }
}

ArbolFrutal::~ArbolFrutal()
{                           //destructor de la case
    //dtor
}
