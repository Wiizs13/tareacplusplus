#include <iostream>
#include <string>
#include"windows.h"  //cabezeras
#include "Fabrica.h"
using namespace std;




Fabrica::Fabrica()
{

}

Arbol* Fabrica::crearArbol(int a) {
    switch(a) {
    case 1:
        return new ArbolFrutal() ;           //menu
        break;
    case 2:
        return new ArbolOrnamental();
        break;
    case 3:
        return new Arbol();     //retorna a las funciones de arbol
        break;
    case 4:
        return new Arbol();
        break;
    case 5:
        return new Arbol();
        break;

    case 6:
        return new Arbol();
        break;
    }
}




Fabrica::~Fabrica()
{
    //dtor
}
