#include "hoja.h"

Hoja::Hoja()
{
    //ctor                  //constructor de la clase
}
void Hoja::Setforma(string val){  //metodo set
    forma = val;
}
string Hoja::Getforma(){ //metodo get
    return forma;
}
void Hoja::Setlongitud(float val){  //metodo set
longitud = val;
}
float Hoja::Getlongitud(){  //metodo get
return longitud;
}
Hoja::~Hoja()
{                           //destructor de la clase
    //dtor
}
