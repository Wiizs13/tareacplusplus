#include "tallo.h"

Tallo::Tallo()
{
    //ctor          //constructor
}
    void Tallo::Setlongitud(float val){     //metodo set
    longitud = val;
    }
    float Tallo::Getlongitud(){         //metodo get
    return longitud;
    }
Tallo::~Tallo()
{
    //dtor
}
