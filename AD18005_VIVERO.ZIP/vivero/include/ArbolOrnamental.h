
#ifndef ARBOLORNAMENTAL_H
#define ARBOLORNAMENTAL_H
#include"hoja.h"
#include "Arbol.h"




class ArbolOrnamental : public Arbol
{
    public:
        ArbolOrnamental();
        void msn();
        virtual ~ArbolOrnamental();

    private:

};

#endif // ARBOLORNAMENTAL_H
