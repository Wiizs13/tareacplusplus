
#ifndef ARBOL_H
#define ARBOL_H
#include "tallo.h"
#include"hoja.h"
#include <iostream>
#include <string>

using namespace std;




class Arbol
{
    public:
        Arbol();
        string get_NComun ();
        void set_NComun(string);

        string get_Ncient ();
        void set_Ncient(string);

        string get_Familia ();
        void set_Familia(string);

        Hoja hoja;
        Tallo tallo;
        virtual void msn(); // es virtual para que sea sobreescrito por las clases hijas
        virtual ~Arbol();

    private:
        string NComun ;
        string Ncient ;
        string Familia ;


};

#endif // ARBOL_H
