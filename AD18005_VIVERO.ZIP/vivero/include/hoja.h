#ifndef HOJA_H
#define HOJA_H
#include "string"

using namespace std;

class Hoja
{
    public:
        Hoja();


        string Getforma() ; //METODO GET
        void Setforma(string val); //METODO SET LE PASO UN STRING
        float Getlongitud() ;   //METODO GET
        void Setlongitud(float val); //METODO SET LE PASO UN FLOAT
  virtual ~Hoja();

    protected:

    private:
        string forma;       //METODOS PRIVADOOS
        float longitud;
};


#endif // HOJA_H
