#ifndef TALLO_H
#define TALLO_H


class Tallo
{
    public:
        Tallo();
        virtual ~Tallo();
        float Getlongitud() ; //METODO GET
        void Setlongitud(float val); //METODO SET LE PASO UN FLOAT
    protected:

    private:
        float longitud;
};

#endif // TALLO_H
