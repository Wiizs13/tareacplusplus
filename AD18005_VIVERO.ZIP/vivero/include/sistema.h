#include <iostream>
#include "Fabrica.h"  //CABEZERAS
#include "windows.h"
#include <stack>
#include <ctime>

//Esta es la clase principal que realiza toda la ejecucion de los procesos


using namespace std;
void ap(int);       //funciones
void ad(float);
void aw(float);
struct Plantas{         //estructura qe se utilizara para la pila
		string nombre;
		string cientifico;
		string familia;
		string forma;
		string tipo;  //METODOS DE LA ESTRUCTURA
		float longitud;
		float longitudta;

};

stack<Plantas>Planta;       //declaracion de la pila

	Plantas *p;     //creamos un puntero de la pila
	Plantas aux; // y una variable auxiliar

void saludo(){      //funcion saludo  imprime mensajes en la pantalla
    system("cls");
   string saludo[10] = {"\t\t\t\t\t\tB","I","E","N","V","E","N","I","D","O\n"};
   for (int i=0;i<10;i++){
    cout<<saludo[i];
    Sleep(150);
   }
      string d[6] = {"\t\t\t\t\t\t V","I","V","E","R","O\n"};
   for (int i=0;i<6;i++){
    cout<<d[i];
    Sleep(150);
   }
}


void menu(){

    int j;
    char e;     //variables de la funcion menu
    char s;
    float m;
    float k;
    string o;
do{
        system("cls");
cout<<"\t\t\t\t\t\tBIENVENIDO\n";
cout<<"\t\t\t\t\t\t VIVERO\n\n\n";
  cout << "\t______________________________\n" <<endl;
  cout << "\t1) Arboles Frutales" <<endl;
  cout << "\t2) Arboles Ornamentales" <<endl;
  cout << "\t3) Ver lista de Arboles" <<endl;       //menu principal
  cout << "\t4) Buscar Arbol" <<endl;
  cout << "\t5) Eliminar Arboles" <<endl;
  cout << "\t6) Salir" <<endl;
  cout << "\t______________________________\n" <<endl;
  cout << "\tPor Favor Ingrese una opcion: ";
    cin>>j;
    ap(j); //se valida j si es numero
   Fabrica f = Fabrica(); //se crea una fabrica f
   Arbol* a = f.crearArbol(j); // creo un nuevo arbol llamado a que sera igual a fabrica. crear atbol que llamada a un menu
   a->msn(); //imprime mensaje

    switch(j) {

    case 1:
        system("cls");
        cout<<"\t\t\t\t\t\tVIVERO\n";
        cout<<"\t\t\t\t\t\tFMO UES\n\n\n";
        aux.tipo= "FRUTAL";
        cout<<" \tIngrese Nombre Comun de el Arbol: ";
        cin>>aux.nombre;
        a->set_NComun(aux.nombre);
        cout<<" \tIngrese Nombre Cientifico de el Arbol: ";
        cin>>aux.cientifico;
        a->set_Ncient(aux.cientifico);
        cout<<" \tIngrese Nombre de la Familia: ";
        cin>>aux.familia;
        a->set_Familia(aux.familia);        //LLENADO DE LOS METODOS DE LA ESTRUCTURA EN UNA VARIABLE AUX
        cout<<" \tDesea agregar el tipo de hoja? (y/n): ";
        cin>>e;
        if(e=='y'|| e=='Y'){  //OPCION SI QUIERE LLENAR LAS HOJAS
        cout<<"\tIngrese la forma de las hojas: ";
        cin>>aux.forma;
        a->hoja.Setforma(aux.forma);
        cout<<"\tIngrese la longitud de las hojas: ";
        cin>>aux.longitud;
        m=aux.longitud;
        ad(m);
        a->hoja.Setlongitud(aux.longitud);
        }
         cout<<" \tDesea agregar el tallo? (y/n): ";
        cin>>s;
        if(s=='y'|| s=='Y'){ //OPCION SI QUIERE LLENAR EL TALLO
        cout<<"\tIngrese la longitud de el tallo: ";
        cin>>aux.longitudta;
        k=aux.longitudta;
        aw(k);
        a->tallo.Setlongitud(aux.longitudta);
        }
        Planta.push(aux); //SE MANDAN LOS DATOS DE AUX A LA PILA
        p=&Planta.top();  // EL APUNTADOR APUNTA A EL TOP
        cout <<"\tArbol Frutal Agregado Correctamente!!"<<endl;
        system("pause");
        break;

    case 2:
        system("cls");
        cout<<"\t\t\t\t\t\tVIVERO\n";
        cout<<"\t\t\t\t\t\tFMO UES\n\n\n";
        aux.tipo= "ORNAMENTAL";
       cout<<" \tIngrese Nombre Comun de el Arbol: ";
        cin>>aux.nombre;
        a->set_NComun(aux.nombre);
        cout<<" \tIngrese Nombre Cientifico de el Arbol: ";  //LLENADO DE LOS METODOS
        cin>>aux.cientifico;
        a->set_Ncient(aux.cientifico);
        cout<<" \tIngrese Nombre de la Familia: ";
        cin>>aux.familia;
        a->set_Familia(aux.familia);
        cout<<" \tDesea agregar el tipo de hoja? (y/n): ";
        cin>>e;
        if(e=='y'|| e=='Y'){   //OPCION SI QUIERE LLENAR LAS HOJAS
        cout<<"\tIngrese la forma de las hojas: ";
        cin>>aux.forma;
        a->hoja.Setforma(aux.forma);
        cout<<"\tIngrese la longitud de las hojas: ";
        cin>>aux.longitud;
        m=aux.longitud;
        ad(m);
        a->hoja.Setlongitud(aux.longitud);

        }
         cout<<" \tDesea agregar el tallo? (y/n): ";  //OPCION SI QUIERE AGREGAR TALLO
        cin>>s;
        if(s=='y'|| s=='Y'){
        cout<<"\tIngrese la longitud de el tallo: ";
        cin>>aux.longitudta;
        k=aux.longitudta;
        aw(k);
        a->tallo.Setlongitud(aux.longitudta);
        }
        Planta.push(aux); //SE MANDAN LOS DATOS DE AUX A LA PILA
        p=&Planta.top();  // EL APUNTADOR APUNTA A EL TOP
        cout <<"\tArbol Ornamental Agregado Correctamente!"<<endl;
        system("pause");
        break;
    case 3:
        system("cls");
                cout<<"\t\t\t\t\t\tVIVERO\n";
                cout<<"\t\t\t\t\t\tFMO UES\n\n\n";

      			if (Planta.empty()) {
                        system("cls");
      			  			cout << "\tEEEEEEE    RRRRRRR     OOOOO     OOOOO   RRRRRRR"<<endl;
				   			cout << "\tEE         RR    RR   O     O   O     O  RR    RR"          <<endl;
				   			cout << "\tEE         RR    RRR O       O O       O RR    RRR"           <<endl;
				   			cout << "\tEEEEEEE    RRRRRRRR  O       O O       O RRRRRRRR"          <<endl;
				   			cout << "\tEE         RR   RR   O       O O       O RR   RR"              <<endl;
				   			cout << "\tEE         RR    RR   O     O   O     O  RR    RR"            <<endl; //MENSAJE DE ERROR
				   			cout << "\tEEEEEEE    RR     RR   OOOOO     OOOOO   RR     RR"          <<endl;
				   					cout<<""<<endl;;
				   			cout<<""<<endl;;
				 			  cout << "___________________________________________"<<endl;
   					    	 cout << "\n\tLa Pila No contiene Informacion para mostrar"<<endl;
   					    	 cout << "\n\tAgrega Plantas!"<<endl;
   					    	 cout << "___________________________________________"<<endl;
   					   		  cout<<""<<endl;;
				   			cout<<""<<endl;;
   					   			  system("pause");

   				 }
   				else {


                  for(int i=1; i<=Planta.size();i++){  //SE HARA UN RECORRIDO HSTA QE SEA MENOR O IGUAL A LA PILA
                    aux=*p;

                cout << "\t___________________________________________"<<endl;
                cout<<"\n\tTipo de Arbol: "<<aux.tipo<<endl;
				cout<<"\tNombre Comun: "<<aux.nombre<<endl;
				cout<<"\tNombre Cientifico: "<<aux.cientifico<<endl;
				cout<<"\tFamilia: "<<aux.familia<<endl;
				cout<<"\tForma de la Hoja: "<<aux.forma<<endl;          //VA IMPRIMIENDO EN PANTALLA LOS DATOS
				cout<<"\tLongitud de la Hoja: "<<aux.longitud<<endl;
				cout<<"\tLongitud de el Tallo: "<<aux.longitudta<<endl;
				cout << "\t___________________________________________"<<endl;
				cout << ""<<endl;
				cout << "\t:::::::::::::::::::::::::::::::::::::::::::"<<endl;
				p--;
				}

			   p=&Planta.top();  //EL APUNTADOR AL TERMINAR EL PROCESO VUELVE A APUNTAR HACIA ARRIBA

			   system("pause");
   				}

        break;
    case 4:
            o = aux.nombre;
            if(Planta.empty()){
                    system("cls");
                            cout << "\tEEEEEEE    RRRRRRR     OOOOO     OOOOO   RRRRRRR           uuuu   uuuu"<<endl;
				   			cout << "\tEE         RR    RR   O     O   O     O  RR    RR          u  u   u  u"          <<endl;
				   			cout << "\tEE         RR    RRR O       O O       O RR    RRR         uuuu   uuuu     "           <<endl;
				   			cout << "\tEEEEEEE    RRRRRRRR  O       O O       O RRRRRRRR                       "  <<endl;
				   			cout << "\tEE         RR   RR   O       O O       O RR   RR             uuuuuuuu    "      <<endl;   //MENSAJE DE ERROR
				   			cout << "\tEE         RR    RR   O     O   O     O  RR    RR          u          u  "            <<endl;
				   			cout << "\tEEEEEEE    RR     RR   OOOOO     OOOOO   RR     RR        u             u"          <<endl;
				   			cout<<""<<endl;;
				   			cout<<""<<endl;;
				 		  cout << "\t___________________________________________"<<endl;
   					     cout << "\n\tLa Pila No contiene Ningun Nodo"<<endl;
   					     cout << "\n\tAgrega Plantas!!"<<endl;
   					     cout << "\t___________________________________________"<<endl;
   					     cout<<""<<endl;;
				   			cout<<""<<endl;;
   					     system("pause");

menu();
}
system("cls");
                cout<<"Ingrese Nombre de Arbol: ";
                cin>>o;

                 for(int i=1; i<=Planta.size();i++){  //SE HARA UN RECORRIDO HSTA QE SEA MENOR O IGUAL A LA PILA
                        aux=*p;

                       if( o==aux.nombre){

                cout << "\t___________________________________________"<<endl;
                cout<<"\n\tTipo de Arbol: "<<aux.tipo<<endl;
				cout<<"\tNombre Comun: "<<aux.nombre<<endl;
				cout<<"\tNombre Cientifico: "<<aux.cientifico<<endl;
				cout<<"\tFamilia: "<<aux.familia<<endl;
				cout<<"\tForma de la Hoja: "<<aux.forma<<endl;          //VA IMPRIMIENDO EN PANTALLA LOS DATOS
				cout<<"\tLongitud de la Hoja: "<<aux.longitud<<endl;
				cout<<"\tLongitud de el Tallo: "<<aux.longitudta<<endl;
				cout << "\t___________________________________________"<<endl;
				cout << ""<<endl;
				cout << "\t:::::::::::::::::::::::::::::::::::::::::::"<<endl;

                       }
                         p--;



				}




      		     p = & Planta.top ();   //APUNTADOR APUNTA HACIA ARRIBA
      		     system("pause");

        break;
    case 5:
        system("cls");
                cout<<"\t\t\t\t\t\tVIVERO\n";
            cout<<"\t\t\t\t\t\tFMO UES\n\n\n";
        if (Planta.empty()){
                system("cls");
				   			cout << "\tEEEEEEE    RRRRRRR     OOOOO     OOOOO   RRRRRRR           uuuu   uuuu"<<endl;
				   			cout << "\tEE         RR    RR   O     O   O     O  RR    RR          u  u   u  u"          <<endl;
				   			cout << "\tEE         RR    RRR O       O O       O RR    RRR         uuuu   uuuu     "           <<endl;
				   			cout << "\tEEEEEEE    RRRRRRRR  O       O O       O RRRRRRRR                       "  <<endl;      //MENSAJE DE ERROR EN CASO QUE LA PILA ESTA VACIA
				   			cout << "\tEE         RR   RR   O       O O       O RR   RR             uuuuuuuu    "      <<endl;
				   			cout << "\tEE         RR    RR   O     O   O     O  RR    RR          u          u  "            <<endl;
				   			cout << "\tEEEEEEE    RR     RR   OOOOO     OOOOO   RR     RR        u             u"          <<endl;
				   			cout<<""<<endl;;
				   			cout<<""<<endl;;
				 		  cout << "\t___________________________________________"<<endl;
   					     cout << "\n\tLa Pila No contiene Ningun Nodo"<<endl;
   					     cout << "\n\tAgrega Plantas!!"<<endl;
   					     cout << "\t___________________________________________"<<endl;
   					     cout<<""<<endl;;
				   			cout<<""<<endl;;
   					     system("pause");
   						 }
    					else {
    						aux=*p;
   					     cout<<"\tNodo eliminado"<<endl;  //IMPRIME MENSAJE
				cout << "\t___________________________________________"<<endl;
                cout<<"\n\tTipo de Arbol: "<<aux.tipo<<endl;
                cout<<"\n\tNombre Comun: "<<aux.nombre<<endl;
				cout<<"\tNombre Cientifico: "<<aux.cientifico<<endl;   //IMPRIME EL NODO QUE SERA ELIMINADO
				cout<<"\tFamilia: "<<aux.familia<<endl;
				cout<<"\tForma de la Hoja: "<<aux.forma<<endl;
				cout<<"\tLongitud de la Hoja: "<<aux.longitud<<endl;
				cout<<"\tLongitud de el Tallo: "<<aux.longitudta<<endl;
				cout << "\t___________________________________________"<<endl;

                 Planta.pop ();   //ELIMINA EL NODO
      		     p = & Planta.top (); //APUNTA HACIA ARRIBA
      		     system("pause");
        }
        break;
    case 6:
        exit(0);
        break;

p = & Planta.top ();
    }

}while(j!=7);

system("pause");

}

void ap (int j){
        while ( cin.fail () ){ //vaidacion si se ingresa una letra.
                cin.clear();
                cin.ignore(1000,'\n');
                system("cls");
                cout<<"LETRAS NO PERMITIDAS"<<endl;//mensaje de error de ingreso.
                system("\tpause");
                menu();
        }
        if (j <= 0 || j>=7 ){ //validacion si se ingresa un numero negativo.
                system("cls");
                cout<<"Ha ingresado un numero no valido"<<endl;//mensaje de error de ingreso.2
                system("pause");
                menu();
        }

}
void ad (float m){
        while ( cin.fail () ){ //vaidacion si se ingresa una letra.
                cin.clear();
                cin.ignore(1000,'\n');
                system("cls");
                cout<<"LETRAS NO PERMITIDAS"<<endl;//mensaje de error de ingreso.
                system("pause");
                system("cls");
        }
        if (m <= 0 ){ //validacion si se ingresa un numero negativo.
                system("cls");
                cout<<"los numeros negativos no son validos"<<endl;//mensaje de error de ingreso.2
                system("pause");
                system("cls");
        }
}
void aw (float k){
        while ( cin.fail () ){ //vaidacion si se ingresa una letra.
                cin.clear();
                cin.ignore(1000,'\n');
                system("cls");
                cout<<"LETRAS NO PERMITIDAS"<<endl;//mensaje de error de ingreso.
                system("pause");
                system("cls");
        }
        if (k <= 0 ){ //validacion si se ingresa un numero negativo.
                system("cls");
                cout<<"los numeros negativos no son validos"<<endl;//mensaje de error de ingreso.2
                system("pause");
                system("cls");
        }
}
