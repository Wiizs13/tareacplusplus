
#ifndef ARBOLFRUTAL_H
#define ARBOLFRUTAL_H
#include "hoja.h"
#include "Arbol.h"
#include <iostream>
#include <string>

using namespace std;

class ArbolFrutal : public Arbol
{
    public:
        ArbolFrutal();
        void msn();
        virtual ~ArbolFrutal();

    protected:

    private:
};

#endif // ARBOLFRUTAL_H
