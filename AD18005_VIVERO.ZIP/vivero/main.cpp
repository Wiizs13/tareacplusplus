#include <iostream>
#include"sistema.h"


using namespace std;

int main()
{


    saludo();       //llama a la funcion saludo de sistema
    menu(); //llama a la funcion menu de sistema


  return 0;

}
