/******************************************************************************
                           Codigo Creado por:
                       Wilbert Alexander Arana Diaz
                       			AD18005
                    Ingeneria en Sistemas Informaticos
*******************************************************************************/


#include <iostream>
#include "clases.h"


using namespace std;



int main() {

	
	PrincipalR *R=new PrincipalR();
	
	PrincipalC *C=new PrincipalC();
	
	
	return 0;
}
