/******************************************************************************
                           Codigo Creado por:
                       Wilbert Alexander Arana Diaz
                       			AD18005
                    Ingeneria en Sistemas Informaticos
*******************************************************************************/

#include <iostream>

using namespace std;
//Clase Principal de el programa
class Figura{
	
	private:  //Metodos privados
			float base;
			float altura;
	public:  //Metodos Publicos podran ser utilizados por todos
			Figura(){ //constructor
				this->base=0; //seteamos base = 0
				this->altura=0; //seteamos altura = 0
			} //cierre de constructor
			Figura(float b, float a) //polimorfismo, Enviamos dos variables de tipo floatantes
			{ 
				this->base=b; //seteamos a base y le decimos que sera igual a B
				this->altura=a; //seteamos a altura y le decimos sera igual a A
			}
			void setbase(float b){ //metodo setbase le enviamos b
				this->base=b;  //seteamos a base y le decimos que sera igual a B
			}
			float getbase(){ //Metodo get se base 
				return this->base; //returno base
			}
			void setaltura(float a){ //Meodo set de altura enviamos dato a
				this->altura=a; //decimos que altura sera igual a A
			}
			float getaltura(){ //Metodo get de altura 
				return this->altura; //retornamos altura
			}
			virtual float area()=0;			//virtual significa que despues se puede sobreescribir sobre el
			virtual float perimetro()=0; //cualquier otra clase podra modificar estos datos	
};

class Color{ //CLASE COLOR SOLO ES DE PRUEBA NO REALIZA NINGUNA FUNCION EN EL PROGRAMA
	public:
			void Colorear(){
				cout<<"estoy pintando"<<endl;
			}
};

class Rectangulo:public Figura, public Color{  //Clase Hijo de Figura 
	public: //Metodos privados
		float area(){ //metodo area
			return getbase()* getaltura(); //retornamos dato de base por altura
		}
		float perimetro(){ //Metodo perimetro
			return 2*getbase()+2*getaltura(); //retornamos get por 2 y altura por 2
		}
	void ImprimirR(){ //Funcion imprimir Rectangulo
		for(int i=0; i<getaltura(); i++){ //utilizamos un for para imprimir datos de altura
			cout<<endl;
			for(int j=0; j<getbase(); j++){ //imprimira asterisco hasta qe sea igual que getbase
				cout<<"* ";
			}
		}
		
	}
};

class Cuadrado:public Figura{ //clase hijo de figura
	public:
		float area(){ //metodo area 
			return getbase()*getbase(); //retornara getbase*getbase
		}
		float perimetro(){ //metodo perimetro
			return 4*getbase(); //retornara getbase por 4 ya que un cuadrado tiene sus cuatro lados iguales
		}
	void ImprimirR(){//funcion para imprimir 
		for(int i=0; i<getbase(); i++){ //imprimira hasta que sea igual a base
			cout<<endl;
			for(int j=0; j<getbase(); j++){ //imprimira hasta que sea igual a base
				cout<<"* ";
			}
		}
		
	}
};


class PrincipalR{ //clase principal que son llamadas en el main
	public: // declaramos metodos publicos
	PrincipalR(){ //metodo
		Rectangulo *r= new Rectangulo();// creamos un nuevo objeto
		r->setbase(6); //asignamos datos a base
		r->setaltura(4); //asignamos datos a altura
		cout<<r->getbase()<<"   "<<r->getaltura()<<endl; //imprimimos el objeto llamando a getbase y getaltura
		cout<<"Area: "<<r->area()<<endl; //imprimimos area que esta siendo llamado por el objeto creado
		cout<<"Perimetro: "<<r->perimetro()<<endl; //imprimimos el perimetro que esta siendo llamado por el objeto
		r->ImprimirR(); //el objeto llama a ala funcion imprimir 
	}
};

class PrincipalC{ //clase principal de el cuadrado que es llamaodo por el main
	public: //declaramos metodos publicos 
	PrincipalC(){ //metodo principalcuadrado
		Cuadrado *c= new Cuadrado(); //creamos un objeto que se llamara c 
		c->setbase(6); //le damos el dato de base ya que medira lo mismo los cuatro lados
		cout<<c->getbase()<<"   "<<endl; //llamamos con el objeto a base
		cout<<"Area: "<<c->area()<<endl; //imprimimos lo de area
		cout<<"Perimetro: "<<c->perimetro()<<endl; //imprimimos el perimetro que esta siendo llamado por el objeto
		c->ImprimirR(); //llama el objeto a la funcion imprimir
	}
};
