#include <iostream>
#include <iostream>
#include <windows.h>
#include <winsock2.h>
#include <mysql.h>
#include <mysqld_error.h> 
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

using namespace std;
int main(int argc, char** argv) {
	
	
	MYSQL * _mysql;
     
    /* Intentar iniciar un objeto MySQL */
    if(!(_mysql = mysql_init(0))) 
    {
     cout << "Error al crear el objeto mysql" << endl;
    }
    else
    {
    	cout << "Objeto mysql creado correctamente, conectando ..." << endl;
      /* Intentar conectar al servidor mysql */
      if(!mysql_real_connect(_mysql, "localhost", "root", "", "practica2", 0, 0, 0))
      {
         cout << "No es posible conectar al servidor" << endl;                              
      }
      else
      {
      	/*****CONSULTA  A LA BASE DE DATOS****/
      	//const char * sql = "SELECT * FROM clientes";//consulta a la bd
      	
      	     char *nombre;
      	     cout<<"Nombre:"<<endl;
      	     cin>>nombre;
      	 	 const char * sql = "insert into clientes values(NULL,'jjj','BONILLA','7898-23','SDDS','DD')";
      
      	 
            int query = mysql_query(_mysql, sql);
            if(query!=0)
            {
            	 cout << "Error en la consulta" << endl; 
			}
			else{
			
        	MYSQL_RES * resultado = mysql_store_result(_mysql);
      	    unsigned long filas_afectadas = mysql_num_rows(resultado);
             MYSQL_ROW fila;
          for (int x = 0; x < filas_afectadas; x++)
          {
              //Obtenemos la fila
              fila = mysql_fetch_row(resultado);
              //Mostrando el valor de los campos de la fila
              cout << fila[0] <<" "<< fila[1] <<" "<< fila[2] << endl;
          }
      	    mysql_free_result(resultado);
      	}
        	mysql_close(_mysql); 
      	
	  }
	}
    system("pause");
    
	return 0;
}
