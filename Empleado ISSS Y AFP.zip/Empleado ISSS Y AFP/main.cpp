#include <iostream>
#include <string.h>
#include <conio.h>
#include "misclases.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

//clase: propiedades y metodos definidos e implementados
//clase abstracta:propiedades , metodos definidos/implementados y por lo menos un metodo sin implementar
//interfaces:son clases que no tienen ningun metodo implementado
int main(int argc, char** argv) {
    float s;

    cout<<"\t\t\t\t\t\tBienvenido"<<endl;
    cout<<"\tIngrese Su Salario: ";
    cin>>s;


	ISSS *d=new ISSS();
//	d->setcodigo(1);
//	d->settipo("isss");
    cout<<"\tTotal ISSS: "<<d->getCalculo(s)<<endl;
    AFP *a=new AFP();
    cout<<"\tTotal AFP: "<<a->getAfp(s)<<endl;
    cout<<"\tSu salario liquido es: "<<(s)-a->getAfp(s)-d->getCalculo(s)<<endl;
    getch();

	return 0;
}
